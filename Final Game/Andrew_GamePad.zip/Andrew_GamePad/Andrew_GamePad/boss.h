#include <Metro.h>
#include "dak_MASK.h"
#include "dak_PIX.h"

Metro dakFrameTimer = Metro(250);
Metro dakBrainTimer = Metro(1000);

int dakMargin;
int dakStatus;
int dakHealth;
int dakType;
int dakSmart;
int dakW;
int dakH;
int dakFrame;

float dakX;
float dakY;
float dakXDir;
float dakYDir;
float dakSpeed;

boolean dakHit;
boolean dakDraw;

void initDak () {

  dakMargin = 4;
  dakHealth = 1;
  dakSmart = 3;
  dakX = 0;
  dakY = 0;
  dakXDir = 0;
  dakYDir = 0;
  dakSpeed = 1;
  dakW = 48;
  dakH = 48;
  dakFrame = 0;

}

void drawDak () {

  if (dakBrainTimer.check()) {
    if (random(0, (dakSmart + 1)) == 0) {
      dakXDir = random(-1, 2);
      dakYDir = random(-1, 2);
    } else {
      if (heroX < dakX) {
        dakXDir = -1;
      }
      else if (heroX > dakX) {
        dakXDir = 1;
      }
      else {
        dakXDir = 0;
      }
      if (heroY < dakY) {
        dakYDir = -1;
      }
      else if (heroY > dakY) {
        dakYDir = 1;
      }
      else {
        dakYDir = 0;
      }
    }
  }

  float nextDX = dakX + (dakXDir * dakSpeed);
  float nextDY = dakY + (dakYDir * dakSpeed);

  if (checkMove(curMode, nextDX, nextDY, dakW, dakH) == true && checkMove2(curMode, nextDX, nextDY, dakW, dakH) == true) {
    dakX = nextDX;
    dakY = nextDY;
  }


  if (dakXDir == 1) {
    if (dakFrameTimer.check()) {
      //dakFrame = 1;
      dakFrame = (dakFrame + 1) % 3;
      dakFrame = dakFrame + 1;
    }
    else if (dakXDir == -1) {
      if (dakFrameTimer.check()) {
        //dakFrame = 1;
        dakFrame = (dakFrame + 1) % 3;
        dakFrame = dakFrame + 1;
      }
    } else {
      dakFrame = 1;
    }
  }

  if (dakYDir == 1) {
    if (dakFrameTimer.check()) {
      //dakFrame = 1;
      dakFrame = (dakFrame + 1) % 7;
      dakFrame = dakFrame + 1;
    }
    else if (dakYDir == -1) {
      if (dakFrameTimer.check()) {
        //dakFrame = 1;
        dakFrame = (dakFrame + 1) % 7;
        dakFrame = dakFrame + 1;
      }
    } else {
      dakFrame = 1;
    }
  }

  tft.setClipRect(dakX - dakMargin, dakY - dakMargin, dakW + dakMargin, dakH + dakMargin);
  drawLevel (curMode);
  tft.drawRGBBitmap (dakX, dakY, dak_PIX[dakFrame], dak_MASK[dakFrame], dakW, dakH);
  tft.updateScreen();
}

void updateDak (int x, int y) {
  dakX = x;
  dakY = y;
  dakDraw = true;
}

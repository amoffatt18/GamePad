#include "officaltitlescreen_MASK.h"
#include "officaltitlescreen_PIX.h"


boolean initIntro = false;
boolean level1 = false;
boolean level2 = false;
boolean level3 = false;
boolean level4 = false;
boolean level5 = false;
boolean level6 = false;


void introScreen () {

  if (initIntro == false) {
    tft.setClipRect(0,0,screenW,screenH);
    tft.drawRGBBitmap(0, 0, officaltitlescreen_PIX[0],officaltitlescreen_MASK[0], screenW, screenH);
    tft.updateScreen();
    initIntro = true;
    //Serial.println ("loading intro");
  }
  if (buttonBuffer[0] == 1) {
    //Serial.println(buttonBuffer[1]);
    curMode = 0;
  }
}

void firstLevel () {

  if (level1 == false) {
    tft.setClipRect (0, 0, screenW, screenH);
    drawLevel(0);
    tft.updateScreen();
    level1 = true;
    Serial.println ("loading level 1");
        enemyX = 100;
        enemyY = 100;
  }
  drawLevel(0);
  drawEnemy();
  drawHero();

  int curTileX = heroX / 20;
  int curTileY = heroY / 20;
  int curTile = curTileX + (curTileY * tileW);
  //Serial.println (interaction[curMode][curTile]);
  Serial.println (curTile);
  if (interaction[curMode][curTile] == 0x01 && buttonBuffer[1] == 1) {
    curMode = 1;
    level1 = false;
  }

}

void secondLevel () {

  if (level2 == false) {
    tft.setClipRect (0, 0, screenW, screenH);
    drawLevel(1);
    tft.updateScreen();
    level2 = true;
    Serial.println ("loading level 2");
  }
  drawLevel(1);
  drawEnemy();
  drawHero();

  int curTileX = heroX / 20;
  int curTileY = heroY / 20;
  int curTile = curTileX + (curTileY * tileW);

  if (interaction[curMode][curTile] == 0x02 && buttonBuffer[3] == 1) {
    curMode = 2;
    level2 = false;
  }

}

void thirdLevel () {

  if (level3 == false) {
    tft.setClipRect (0, 0, screenW, screenH);
    drawLevel(2);
    tft.updateScreen();
    level3 = true;
    Serial.println ("loading level 3");
  }
  drawLevel(2);
  drawEnemy();
  drawHero();

  int curTileX = heroX / 20;
  int curTileY = heroY / 20;
  int curTile = curTileX + (curTileY * tileW);

  if (interaction[curMode][curTile] == 0x03 && buttonBuffer[1] == 1) {
    curMode = 3;
    level3 = false;
  }

}

void fourthLevel () {
  if (level4 == false) {
    tft.setClipRect (0, 0, screenW, screenH);
    drawLevel(3);
    tft.updateScreen();
    level4 = true;
  }
  drawLevel(3);
  drawEnemy();
  drawHero();

  int curTileX = heroX / 20;
  int curTileY = heroY / 20;
  int curTile = curTileX + (curTileY * tileW);

  if (interaction[curMode][curTile] == 0x04 && buttonBuffer[3] == 1) {
    curMode = 4;
    level4 = false;
  }

}

void fifthLevel () {
  if (level5 == false) {
    tft.setClipRect (0, 0, screenW, screenH);
    drawLevel(4);
    tft.updateScreen();
    level5 = true;
  }
  drawLevel(4);
  drawEnemy();
  drawHero();

  int curTileX = heroX / 20;
  int curTileY = heroY / 20;
  int curTile = curTileX + (curTileY * tileW);

  if (interaction[curMode][curTile] == 0x05 && buttonBuffer[1] == 1) {
    curMode = 5;
    level5 = false;
  }

}

void bossLevel () {
  if (level6 == false) {
    tft.setClipRect (0, 0, screenW, screenH);
    drawLevel(5);
    tft.updateScreen();
    level6 = true;
    dakX = 150;
    dakY = 150;
  }
  drawLevel(5);
  drawDak();
  drawHero();

  //  if (buttonBuffer[0] == 1) {
  //    curMode = -1;
  //  }
  int curTileX = heroX / 20;
  int curTileY = heroY / 20;
  int curTile = curTileX + (curTileY * tileW);

    if (interaction[curMode][curTile] == 0x06 && buttonBuffer[3] == 1) {
      curMode = 0;
      level6 = false;
    }
}

void runMode() {

  switch (curMode) {
    case -1: introScreen(); break;
    case 0: firstLevel(); break;
    case 1: secondLevel(); break;
    case 2: thirdLevel(); break;
    case 3: fourthLevel(); break;
    case 4: fifthLevel(); break;
    case 5: bossLevel(); break;

  }
}
